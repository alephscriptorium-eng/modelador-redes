Colectivizaciones libertarias 1936-37 sobre Oasis/SSB — Revisión (índice de estado + fichas)
Modelo: colectivizaciones · rama dev/colectivizaciones · estado: en revisión
Draft vigente: draftv1.md
Modelador de Redes v0.2.0 · https://github.com/alephscriptorium-eng/modelador-redes
Licencia del contenido: GPL-3.0-or-later AND LicenseRef-Animus-Iocandi

Los enlaces a Oasis apuntan a https://github.com/epsylon/oasis en el commit auditado 9a657b776fcafc7c24bf3ad61825316385ecf513.
Oasis (AGPL-3.0) no se incluye en este paquete.

Archivos incluidos:
  - revision/00-indice.md
  - revision/01-asamblea.md
  - revision/02-cargos.md
  - revision/03-propiedad.md
  - revision/04-salario-familiar.md
  - revision/05-federacion.md
  - revision/06-intercambio.md
  - revision/07-derechos-sociales.md
  - revision/08-fuentes-d01.md
  - revision/09-fuentes-d02.md
  - revision/10-fuentes-d03.md
  - revision/11-fuentes-d04.md

Generado con `modelador build`. Fuente canónica: el repositorio.
