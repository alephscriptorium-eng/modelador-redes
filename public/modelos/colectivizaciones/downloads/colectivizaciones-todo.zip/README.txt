Colectivizaciones libertarias 1936-37 sobre Oasis/SSB — Paquete completo del modelo
Modelo: colectivizaciones · rama dev/colectivizaciones · estado: en revisión
Draft vigente: draftv0.md
Modelador de Redes v0.1.0 · https://github.com/alephscriptorium-eng/modelador-redes
Licencia del contenido: GPL-3.0-or-later AND LicenseRef-Animus-Iocandi

Los enlaces a Oasis apuntan a https://github.com/epsylon/oasis en el commit auditado 9a657b776fcafc7c24bf3ad61825316385ecf513.
Oasis (AGPL-3.0) no se incluye en este paquete.

Archivos incluidos:
  - drafts/draft.md
  - drafts/draftv0.md
  - modelo.json
  - revision/00-indice.md
  - revision/01-asamblea.md
  - revision/02-cargos.md
  - revision/03-propiedad.md
  - revision/04-salario-familiar.md
  - revision/05-federacion.md
  - revision/06-intercambio.md
  - revision/07-derechos-sociales.md

Generado con `modelador build`. Fuente canónica: el repositorio.
