República Pura (Trevijano) sobre Oasis/SSB — Revisión (índice de estado + fichas)
Modelo: res_publica · rama dev/res_publica · estado: en revisión
Draft vigente: draftv2.md
Modelador de Redes v0.1.0 · https://github.com/alephscriptorium-eng/modelador-redes
Licencia del contenido: GPL-3.0-or-later AND LicenseRef-Animus-Iocandi

Los enlaces a Oasis apuntan a https://github.com/epsylon/oasis en el commit auditado 9a657b776fcafc7c24bf3ad61825316385ecf513.
Oasis (AGPL-3.0) no se incluye en este paquete.

Archivos incluidos:
  - revision/00-indice.md
  - revision/01-lealtad.md
  - revision/02-monada.md
  - revision/03-camara.md
  - revision/04-legislacion.md
  - revision/05-justicia.md
  - revision/06-gobierno.md
  - revision/07-constituyente.md
  - revision/08-republica.md

Generado con `modelador build`. Fuente canónica: el repositorio.
