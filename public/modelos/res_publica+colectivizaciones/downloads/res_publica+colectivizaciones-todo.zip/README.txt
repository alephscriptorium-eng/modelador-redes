Contraste: República Pura ↔ colectivizaciones 1936-37 — Paquete completo del modelo
Modelo: res_publica+colectivizaciones · rama dev/res_publica+colectivizaciones · estado: pausa
Draft vigente: draft.md
Modelador de Redes v0.2.0 · https://github.com/alephscriptorium-eng/modelador-redes
Licencia del contenido: GPL-3.0-or-later AND LicenseRef-Animus-Iocandi

Los enlaces a Oasis apuntan a https://github.com/epsylon/oasis en el commit auditado 9a657b776fcafc7c24bf3ad61825316385ecf513.
Oasis (AGPL-3.0) no se incluye en este paquete.

Archivos incluidos:
  - drafts/draft.md
  - modelo.json
  - revision/00-indice.md

Generado con `modelador build`. Fuente canónica: el repositorio.
