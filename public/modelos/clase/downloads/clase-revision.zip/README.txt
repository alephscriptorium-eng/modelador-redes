Materialismo filosófico (Gustavo Bueno) sobre Oasis/SSB — Revisión (índice de estado + fichas)
Modelo: clase · rama dev/clase · estado: auditoría sin revisar
Draft vigente: draftv0.md
Modelador de Redes v0.2.0 · https://github.com/alephscriptorium-eng/modelador-redes
Licencia del contenido: GPL-3.0-or-later AND LicenseRef-Animus-Iocandi

Los enlaces a Oasis apuntan a https://github.com/epsylon/oasis en el commit auditado 9a657b776fcafc7c24bf3ad61825316385ecf513.
Oasis (AGPL-3.0) no se incluye en este paquete.

Archivos incluidos:
  - revision/00-indice.md
  - revision/01-costuras.md

Generado con `modelador build`. Fuente canónica: el repositorio.
