Materialismo filosófico (Gustavo Bueno) sobre Oasis/SSB — Drafts (borradores sucesivos, el de sufijo mayor es el vigente)
Modelo: clase · rama dev/clase · estado: auditoría sin revisar
Draft vigente: draftv0.md
Modelador de Redes v0.2.0 · https://github.com/alephscriptorium-eng/modelador-redes
Licencia del contenido: GPL-3.0-or-later AND LicenseRef-Animus-Iocandi

Los enlaces a Oasis apuntan a https://github.com/epsylon/oasis en el commit auditado 9a657b776fcafc7c24bf3ad61825316385ecf513.
Oasis (AGPL-3.0) no se incluye en este paquete.

Archivos incluidos:
  - drafts/draft.md
  - drafts/draftv0.md

Generado con `modelador build`. Fuente canónica: el repositorio.
